package telran.time.tools;

public class DateOperation {
	
	public static int getAge(String birthDate) {
		//TODO
		return 0;
	}
	
	public static String[] sortStringDate(String[] dates) {
		//TODO
		return null;
	}

}
